.. pretty_midi documentation master file, created by
   sphinx-quickstart on Mon Jul 21 14:25:59 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pretty_midi
===========
.. automodule:: pretty_midi.pretty_midi
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

